import unittest
from max_number import *

'''print(max_number.__doc__)'''


class TestFindMaxNumber(unittest.TestCase):
# Finding the highest Value unit Test

    def test_max(self):
        assert max1([3, 5, 9, 12, 78]) == 78, "78 is the max number"


#print(max_number.__doc__)
    def test_list_decending_order(self):
        assert list_decending_order([3, 5, 99, 9, 12, 78]) == [99, 78, 12, 9, 5, 3], "[99, 78, 12, 9, 5, 3] in decending order"