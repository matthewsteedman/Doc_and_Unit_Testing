# finding the highest value in A LIST
def max1(my_list):
    '''
    >>> max1([3, 5, 99, 9, 12, 78])
    99
    '''
    return max(my_list)


print(max1([3, 5, 99, 9, 12, 78]))

# Ordering a list in descending order using a function


def list_decending_order(my_list):
    '''
    >>> list_decending_order([3, 5, 99, 9, 12, 78])
    [99, 78, 12, 9, 5, 3]
    '''
    my_list = [3, 5, 99, 9, 12, 78]

    x = sorted(my_list, reverse=True)

    return x


print(list_decending_order([3, 5, 99, 9, 12, 78]))
